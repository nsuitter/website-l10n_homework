
document.getElementById('stopButton').onclick = activateRed;
document.getElementById('slowButton').onclick = activateYellow;
document.getElementById('goButton').onclick = activateGreen;

function activateRed() {
  blacklights();
  document.getElementById('stopLight').style.backgroundColor = "red";
}

function activateYellow() {
  blacklights();
  document.getElementById('slowLight').style.backgroundColor = "yellow";
}

function activateGreen() {
  blacklights();
  document.getElementById('goLight').style.backgroundColor = "green";
}

function blacklights() {
  document.getElementById('stopLight').style.backgroundColor = "black";
  document.getElementById('slowLight').style.backgroundColor = "black";
  document.getElementById('goLight').style.backgroundColor = "black";
}
