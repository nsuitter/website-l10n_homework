#!/bin/bash
start "" "./styleguide.docx"
explorer http://www.linguee.com/
explorer http://www.google.com/
